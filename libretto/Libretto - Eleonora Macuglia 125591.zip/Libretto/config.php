<?php

define('HOST', 'localhost');
define('DBNAME', 'ctw_macuglia');
define('USERNAME', 'ctw_macuglia');
define('PASSWORD', 'finalfantasy13');
?>